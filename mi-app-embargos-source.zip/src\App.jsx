import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Search, Upload, FileDown, AlertCircle, CheckCircle, XCircle, ChevronDown, ChevronRight, ChevronsUpDown, Eye, Edit, Gavel, ShieldCheck, Trash2, PlusCircle, Filter, MoreVertical, Folder, FileText } from 'lucide-react';

// --- MOCK DATA ---
const MOCK_USERS_ACCOUNTS = {
  '20304050601': {
    cuit: '20-30405060-1',
    name: 'Juan Carlos Rodriguez',
    accounts: [
      { id: 'acc-mp-1', society: 'Mercado Pago', type: 'Remunerada', balance: 150000.75, status: 'active' },
      { id: 'acc-alyc-1', society: 'Mercado Crédito ALyC', type: 'FCI', balance: 1000.00, status: 'active' },
      { id: 'acc-sofi-1', society: 'Mercado SOFI', type: 'Inversión', balance: 25000.50, status: 'active' },
      { id: 'acc-mp-2', society: 'Mercado Pago', type: 'No Remunerada', balance: 500.00, status: 'inactive' },
    ]
  },
  '27358765432': {
    cuit: '27-35876543-2',
    name: 'Maria Elena Gonzalez',
    accounts: [
      { id: 'acc-mp-3', society: 'Mercado Pago', type: 'Remunerada', balance: 8500.20, status: 'active' },
      { id: 'acc-banco-1', society: 'Banco de México', type: 'Caja de Ahorro', balance: 120000.00, status: 'active' },
    ]
  },
  '20123456789': {
    cuit: '20-12345678-9',
    name: 'Pedro Ramirez',
    accounts: [
      { id: 'acc-mp-4', society: 'Mercado Pago', type: 'Remunerada', balance: 120.30, status: 'active' }
    ]
  }
};

const INITIAL_GROUPED_EMBARGOES = [
    {
        groupId: 'CASE-20304050601-12345/2023',
        userCuit: '20304050601',
        userName: 'Juan Carlos Rodriguez',
        docket: '12345/2023',
        caseNumber: 'RODRIGUEZ JUAN C/ MERCADOLIBRE S.R.L. S/ EJECUTIVO',
        court: 'Juzgado Nacional en lo Comercial N° 5',
        createdDate: '2024-07-15T10:00:00Z',
        state: 'En Curso',
        transfers: [],
        subEmbargoes: [
            {
                id: 'EMB-001-MP',
                state: 'Completo',
                society: 'Mercado Pago',
                accountsInvolved: ['acc-mp-1'],
                amount: 40000.00,
                capturedAmount: 40000.00,
                history: [{ action: 'Creación', user: 'creator@mercadolibre.com', date: '2024-07-15T10:00:00Z', details: 'Embargo creado y completado por $40,000.00' }],
            },
            {
                id: 'EMB-001-ALYC',
                state: 'En Proceso',
                society: 'Mercado Crédito ALyC',
                accountsInvolved: ['acc-alyc-1'],
                amount: 10000.00,
                capturedAmount: 1000.00,
                history: [{ action: 'Creación', user: 'creator@mercadolibre.com', date: '2024-07-15T10:00:00Z', details: 'Embargo creado por $10,000.00. Captura inicial: $1,000.00' }],
            }
        ]
    },
    {
        groupId: 'CASE-27358765432-54321/2024',
        userCuit: '27358765432',
        userName: 'Maria Elena Gonzalez',
        docket: '54321/2024',
        caseNumber: 'GONZALEZ MARIA E/ BANCO DE MEXICO S.A. S/ DAÑOS',
        court: 'Juzgado Civil y Comercial N° 12',
        createdDate: '2024-07-14T15:30:00Z',
        state: 'Pendiente de Transferencia',
        transfers: [{ id: 'TRN-001', date: '2024-07-16T11:00:00Z', amount: 75000.00, cbu: '0170012345678901234567', bank: 'Banco Provincia', status: 'Pendiente Aprobación', receipt: null }],
        subEmbargoes: [
            {
                id: 'EMB-002-BM',
                state: 'Completo',
                society: 'Banco de México',
                accountsInvolved: ['acc-banco-1'],
                amount: 75000.00,
                capturedAmount: 75000.00,
                history: [{ action: 'Creación', user: 'creator@mercadolibre.com', date: '2024-07-14T15:30:00Z', details: 'Embargo creado y completado por $75,000.00' }],
            },
            {
                id: 'EMB-004-MP',
                state: 'Levantado',
                society: 'Mercado Pago',
                accountsInvolved: ['acc-mp-3'],
                amount: 5000.00,
                capturedAmount: 0,
                history: [
                    { action: 'Creación', user: 'creator@mercadolibre.com', date: '2024-06-20T12:00:00Z', details: 'Embargo creado por $5,000.00' },
                    { action: 'Levantamiento Total', user: 'creator@mercadolibre.com', date: '2024-07-01T16:00:00Z', details: 'Levantamiento total por orden judicial.' },
                ],
            }
        ]
    }
];


const ROLES = {
  VIEWER: { name: 'Embargo Viewer', permissions: ['view'] },
  CREATOR: { name: 'Embargo Creator', permissions: ['view', 'create', 'act'] },
  APPROVER: { name: 'Transfer Approver', permissions: ['view', 'create', 'act', 'approve'] },
};

// --- HELPER FUNCTIONS ---
const formatCurrency = (value) => new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' }).format(value);
const formatDate = (dateString) => new Date(dateString).toLocaleDateString('es-AR', { year: 'numeric', month: '2-digit', day: '2-digit' });
const calculateTotalActiveAmount = (subEmbargoes) => subEmbargoes.reduce((sum, sub) => sub.state !== 'Levantado' ? sum + sub.amount : sum, 0);
const calculateTotalCapturedAmount = (subEmbargoes) => subEmbargoes.reduce((sum, sub) => sub.state !== 'Levantado' ? sum + sub.capturedAmount : sum, 0);
const getGroupState = (group) => {
    if (group.state === 'Pendiente de Transferencia') return 'Pendiente de Transferencia';
    const activeSubs = group.subEmbargoes.filter(s => s.state !== 'Levantado');
    if (activeSubs.length === 0) return 'Levantado';
    if (activeSubs.every(s => s.state === 'Completo' || s.state === 'Transferido')) return 'Completo';
    return 'En Curso';
};


// --- UI COMPONENTS ---

const Spinner = () => <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>;

const ToastNotification = ({ message, type, onDismiss }) => {
  if (!message) return null;
  const bgColor = { success: 'bg-green-100 border-green-500 text-green-700', error: 'bg-red-100 border-red-500 text-red-700', info: 'bg-blue-100 border-blue-500 text-blue-700' }[type];
  const Icon = { success: CheckCircle, error: XCircle, info: AlertCircle }[type];
  useEffect(() => { const timer = setTimeout(onDismiss, 5000); return () => clearTimeout(timer); }, [onDismiss]);
  return (
    <div className={`fixed top-5 right-5 z-50 p-4 rounded-lg border ${bgColor} shadow-lg flex items-center animate-fade-in-down`}>
      <Icon className="h-6 w-6 mr-3" />
      <span>{message}</span>
      <button onClick={onDismiss} className="ml-4 text-xl font-bold">&times;</button>
    </div>
  );
};

const ConfirmationModal = ({ isOpen, title, message, onConfirm, onCancel, confirmText = "Confirmar", cancelText = "Cancelar", children }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center">
      <div className="bg-white rounded-lg p-8 shadow-2xl w-full max-w-md m-4">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">{title}</h2>
        {message && <p className="text-gray-600 mb-6">{message}</p>}
        {children}
        <div className="flex justify-end space-x-4 mt-8">
          <button onClick={onCancel} className="px-6 py-2 rounded-md text-gray-700 bg-gray-200 hover:bg-gray-300 font-semibold transition-colors">{cancelText}</button>
          <button onClick={onConfirm} className="px-6 py-2 rounded-md text-white bg-blue-600 hover:bg-blue-700 font-semibold transition-colors">{confirmText}</button>
        </div>
      </div>
    </div>
  );
};

const StateBadge = ({ state }) => {
  const styles = { 'En Curso': 'bg-blue-100 text-blue-800', 'Pendiente de Transferencia': 'bg-orange-100 text-orange-800', 'Completo': 'bg-green-100 text-green-800', 'Levantado': 'bg-gray-100 text-gray-800', 'En Proceso': 'bg-yellow-100 text-yellow-800', 'Transferido': 'bg-purple-100 text-purple-800'}[state] || 'bg-gray-200 text-gray-900';
  return <span className={`px-3 py-1 text-sm font-medium rounded-full ${styles}`}>{state}</span>;
};

const Sidebar = ({ setCurrentPage }) => (
  <aside className="w-64 bg-gray-800 text-white flex flex-col">
    <div className="h-16 flex items-center justify-center text-2xl font-bold border-b border-gray-700"><Gavel className="mr-2" /> MELI Legal</div>
    <nav className="flex-1 px-4 py-6">
      <ul>
        <li><button onClick={() => setCurrentPage({name: 'list'})} className="w-full text-left flex items-center py-3 px-4 rounded-md hover:bg-gray-700 transition-colors"><ChevronRight className="mr-3 h-5 w-5" /> Lista de Embargos</button></li>
        <li><button onClick={() => setCurrentPage({name: 'create'})} className="w-full text-left flex items-center py-3 px-4 rounded-md hover:bg-gray-700 transition-colors"><PlusCircle className="mr-3 h-5 w-5" /> Crear Embargo</button></li>
        <li><button onClick={() => setCurrentPage({name: 'bulk'})} className="w-full text-left flex items-center py-3 px-4 rounded-md hover:bg-gray-700 transition-colors"><Upload className="mr-3 h-5 w-5" /> Carga Masiva</button></li>
        <li><button onClick={() => setCurrentPage({name: 'lookup'})} className="w-full text-left flex items-center py-3 px-4 rounded-md hover:bg-gray-700 transition-colors"><Search className="mr-3 h-5 w-5" /> Cuentas y Saldos</button></li>
      </ul>
    </nav>
  </aside>
);

const AccountLookupComponent = ({ onAccountsFound, initialCuit = '' }) => {
    const [cuit, setCuit] = useState(initialCuit);
    const [foundUser, setFoundUser] = useState(null);
    const [error, setError] = useState('');
    const handleSearch = () => {
        setError(''); setFoundUser(null);
        const user = MOCK_USERS_ACCOUNTS[cuit.replace(/-/g, '')];
        if (user) { setFoundUser(user); if(onAccountsFound) onAccountsFound(user); } 
        else { setError('CUIT/DNI no encontrado.'); if(onAccountsFound) onAccountsFound(null); }
    };
    useEffect(() => { if(initialCuit) { handleSearch(); } }, [initialCuit]);
    return (
        <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex space-x-2 mb-4">
                <input type="text" value={cuit} onChange={(e) => setCuit(e.target.value)} placeholder="Buscar por CUIT o DNI" className="flex-grow p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                <button onClick={handleSearch} className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center"><Search className="mr-2 h-4 w-4" /> Buscar</button>
            </div>
            {error && <p className="text-red-500 mt-2">{error}</p>}
            {foundUser && (
                <div className="mt-4 animate-fade-in">
                    <h3 className="text-lg font-bold text-gray-800">{foundUser.name} <span className="font-normal text-gray-500">({foundUser.cuit})</span></h3>
                    <div className="mt-2 border-t pt-2">
                        {foundUser.accounts.map(acc => (
                            <div key={acc.id} className="p-3 my-2 border rounded-md flex justify-between items-center bg-gray-50">
                                <div><p className="font-semibold">{acc.type} <span className={`text-xs font-bold ${acc.status === 'active' ? 'text-green-600' : 'text-red-600'}`}>({acc.status === 'active' ? 'Activa' : 'Inactiva'})</span></p><p className="text-sm text-gray-600">ID: {acc.id}</p></div>
                                <div className="text-right"><p className="font-bold text-lg">{formatCurrency(acc.balance)}</p><p className="text-sm font-semibold text-blue-700">{acc.society}</p></div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

const CreateEmbargoPage = ({ onEmbargoCreate, setCurrentPage }) => {
    const [step, setStep] = useState(1);
    const [cuit, setCuit] = useState('');
    const [foundUser, setFoundUser] = useState(null);
    const [selectedAccounts, setSelectedAccounts] = useState([]);
    const [subAmounts, setSubAmounts] = useState({});
    const [court, setCourt] = useState('');
    const [docket, setDocket] = useState('');
    const [caseNumber, setCaseNumber] = useState('');
    const [notes, setNotes] = useState('');
    const [error, setError] = useState('');
    const [confirmationData, setConfirmationData] = useState(null);
    const totalAmount = useMemo(() => Object.values(subAmounts).reduce((sum, amt) => sum + (parseFloat(amt) || 0), 0), [subAmounts]);
    const handleSearch = () => {
        setError(''); const user = MOCK_USERS_ACCOUNTS[cuit.replace(/-/g, '')];
        if (user) { setFoundUser(user); setStep(2); } 
        else { setError('CUIT/DNI no encontrado.'); }
    };
    const handleAccountToggle = (accountId) => {
        const newSelectedAccounts = selectedAccounts.includes(accountId) ? selectedAccounts.filter(id => id !== accountId) : [...selectedAccounts, accountId];
        setSelectedAccounts(newSelectedAccounts);
        const newSubAmounts = { ...subAmounts };
        if (!newSelectedAccounts.includes(accountId)) { delete newSubAmounts[accountId]; }
        setSubAmounts(newSubAmounts);
    };
    const handleSubAmountChange = (accountId, value) => { setSubAmounts(prev => ({ ...prev, [accountId]: value })); };
    const handleSubmit = (e) => {
        e.preventDefault(); setError('');
        if (totalAmount <= 0) { setError('El monto total a embargar debe ser mayor a cero.'); return; }
        if (!docket) { setError('El campo "Expediente" es obligatorio para agrupar los embargos.'); return; }
        const societyData = {};
        for (const accountId in subAmounts) {
            const amount = parseFloat(subAmounts[accountId] || 0);
            if (amount > 0) {
                const account = foundUser.accounts.find(a => a.id === accountId);
                if (account) {
                    const { society } = account;
                    if (!societyData[society]) { societyData[society] = { totalAmount: 0 }; }
                    societyData[society].totalAmount += amount;
                }
            }
        }
        setConfirmationData({ societyData, totalAmount });
    };
    const handleConfirmCreation = () => {
        onEmbargoCreate({ foundUser, subAmounts, court, docket, caseNumber, notes });
        setConfirmationData(null);
    };
    return (
        <div className="p-8">
            <div className="flex justify-between items-center mb-6">
                 <h1 className="text-3xl font-bold text-gray-800">Crear Nuevo Embargo</h1>
                 <button onClick={() => setCurrentPage({name: 'list'})} className="text-blue-600 hover:text-blue-800 font-semibold flex items-center">
                    &larr; Volver a la lista
                </button>
            </div>
            {confirmationData && (
                <ConfirmationModal isOpen={true} title="Confirmar Creación de Embargo(s)" onConfirm={handleConfirmCreation} onCancel={() => setConfirmationData(null)} confirmText="Crear Embargo(s)">
                    <div className="text-gray-600">
                        <p>Se crearán embargos para el usuario <span className="font-semibold">{foundUser.name}</span> con el siguiente detalle:</p>
                        <ul className="list-disc list-inside my-4 bg-gray-50 p-3 rounded-md">
                            {Object.entries(confirmationData.societyData).map(([society, data]) => (
                                <li key={society}><span className="font-semibold">{society}:</span> {formatCurrency(data.totalAmount)}</li>
                            ))}
                        </ul>
                        <p className="text-lg font-bold border-t pt-2">Monto Total: {formatCurrency(confirmationData.totalAmount)}</p>
                    </div>
                </ConfirmationModal>
            )}
            {step === 1 && (
                <div className="bg-white p-6 rounded-lg shadow-md max-w-lg mx-auto">
                    <h2 className="text-xl font-semibold mb-4">1. Buscar Usuario</h2>
                    <div className="flex space-x-2"><input type="text" value={cuit} onChange={(e) => setCuit(e.target.value)} placeholder="Ingresar CUIT o DNI del usuario" className="flex-grow p-2 border rounded-md focus:ring-2 focus:ring-blue-500" /><button onClick={handleSearch} className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center"><Search className="mr-2 h-4 w-4" /> Buscar</button></div>
                    {error && <p className="text-red-500 mt-2">{error}</p>}
                </div>
            )}
            {step === 2 && foundUser && (
                <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-md animate-fade-in">
                    <h2 className="text-2xl font-semibold mb-4">2. Detalle del Embargo</h2>
                    <div className="mb-6 p-4 border rounded-md bg-gray-50"><h3 className="font-bold text-lg">{foundUser.name}</h3><p className="text-gray-600">{foundUser.cuit}</p></div>
                    <div className="mb-6"><h3 className="font-semibold text-lg mb-2">Seleccionar Cuentas y Definir Montos a Embargar</h3><div className="space-y-2">{foundUser.accounts.map(acc => (<div key={acc.id} className={`p-3 border rounded-md transition-all ${selectedAccounts.includes(acc.id) ? 'bg-blue-50 border-blue-500' : 'bg-white'} ${acc.status !== 'active' ? 'opacity-50' : ''}`}><div className="flex items-center justify-between"><div className="flex items-center"><input type="checkbox" id={`cb-${acc.id}`} checked={selectedAccounts.includes(acc.id)} onChange={() => handleAccountToggle(acc.id)} disabled={acc.status !== 'active'} className="h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500 disabled:opacity-50" /><label htmlFor={`cb-${acc.id}`} className="ml-4 cursor-pointer"><p className="font-medium">{acc.type} {acc.status !== 'active' && <span className="text-xs text-red-500">(Inactiva)</span>}</p><p className="text-sm text-gray-500">Saldo: {formatCurrency(acc.balance)}</p></label></div><p className="text-sm font-semibold text-blue-700">{acc.society}</p></div>{selectedAccounts.includes(acc.id) && (<div className="mt-2 pl-8 animate-fade-in"><label htmlFor={`amount-${acc.id}`} className="block text-sm font-medium text-gray-700">Monto a embargar de esta cuenta:</label><input type="number" id={`amount-${acc.id}`} value={subAmounts[acc.id] || ''} onChange={(e) => handleSubAmountChange(acc.id, e.target.value)} placeholder="0.00" className="w-full max-w-xs p-2 border rounded-md focus:ring-2 focus:ring-blue-500" /></div>)}</div>))}</div></div>
                    <div className="my-8 p-6 bg-gray-100 rounded-lg text-center"><label className="block text-xl font-bold text-gray-800 mb-2">Monto Total a Embargar (ARS)</label><p className="text-4xl font-bold text-blue-600">{formatCurrency(totalAmount)}</p></div>
                    <div className="mb-6 p-4 border-l-4 border-gray-300 bg-gray-50"><h3 className="font-semibold text-lg mb-2">Datos Judiciales (Obligatorios para Agrupar)</h3><div className="grid grid-cols-1 md:grid-cols-2 gap-6"><div><label htmlFor="court" className="block text-sm font-medium text-gray-700 mb-1">Juzgado</label><input type="text" id="court" value={court} onChange={e => setCourt(e.target.value)} className="w-full p-2 border rounded-md" /></div><div><label htmlFor="docket" className="block text-sm font-medium text-gray-700 mb-1">Expediente *</label><input type="text" id="docket" value={docket} onChange={e => setDocket(e.target.value)} required className="w-full p-2 border rounded-md" /></div><div className="md:col-span-2"><label htmlFor="caseNumber" className="block text-sm font-medium text-gray-700 mb-1">Carátula</label><input type="text" id="caseNumber" value={caseNumber} onChange={e => setCaseNumber(e.target.value)} className="w-full p-2 border rounded-md" /></div><div className="md:col-span-2"><label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">Notas</label><textarea id="notes" value={notes} onChange={e => setNotes(e.target.value)} rows="3" className="w-full p-2 border rounded-md"></textarea></div></div></div>
                    {error && <p className="text-red-500 my-4 p-3 bg-red-50 border border-red-300 rounded-md">{error}</p>}
                    <div className="flex justify-end space-x-4"><button type="button" onClick={() => setCurrentPage({name: 'list'})} className="px-6 py-2 rounded-md text-gray-700 bg-gray-200 hover:bg-gray-300 font-semibold">Cancelar</button><button type="submit" className="px-6 py-2 rounded-md text-white bg-blue-600 hover:bg-blue-700 font-semibold flex items-center"><Gavel className="mr-2 h-5 w-5" /> Crear Embargo</button></div>
                </form>
            )}
        </div>
    );
};

const ActionsDropdown = ({ subEmbargo, onAction, currentRole, groupId }) => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef(null);
    const can = (permission) => currentRole.permissions.includes(permission);
    useEffect(() => { const handleClickOutside = (e) => { if (dropdownRef.current && !dropdownRef.current.contains(e.target)) setIsOpen(false); }; document.addEventListener("mousedown", handleClickOutside); return () => document.removeEventListener("mousedown", handleClickOutside); }, []);
    const handleActionClick = (action, id) => { onAction(action, id, groupId); setIsOpen(false); };
    const hasActions = can('act') && subEmbargo.state !== 'Levantado' && subEmbargo.state !== 'Transferido';
    if (!hasActions) return <div className="w-24 text-center">-</div>;
    return (
        <div className="relative" ref={dropdownRef}>
            <button onClick={() => setIsOpen(!isOpen)} className="p-2 text-gray-500 hover:text-blue-600 hover:bg-gray-100 rounded-full"><MoreVertical className="h-5 w-5" /></button>
            {isOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10 border">
                    <ul className="py-1">
                        <li><button onClick={() => handleActionClick('lift', subEmbargo.id)} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"><Trash2 className="mr-2 h-4 w-4 text-red-500"/>Levantar</button></li>
                        <li><button onClick={() => handleActionClick('modify', subEmbargo.id)} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"><Edit className="mr-2 h-4 w-4 text-yellow-500"/>Modificar</button></li>
                    </ul>
                </div>
            )}
        </div>
    );
};

const EmbargoListPage = ({ groupedEmbargoes, onAction, currentRole, setPage, onMassApprove }) => {
    const [filters, setFilters] = useState({ state: '', cuit: '', society: '' });
    const [sortConfig, setSortConfig] = useState({ key: 'createdDate', direction: 'descending' });
    const [expandedRows, setExpandedRows] = useState([]);
    const toggleRow = (groupId) => setExpandedRows(prev => prev.includes(groupId) ? prev.filter(id => id !== groupId) : [...prev, groupId]);
    const sortedAndFilteredEmbargoes = useMemo(() => {
        let filtered = [...groupedEmbargoes];
        if (filters.cuit) filtered = filtered.filter(g => g.userCuit.includes(filters.cuit.replace(/-/g, '')) || g.userName.toLowerCase().includes(filters.cuit.toLowerCase()));
        if (filters.society) filtered = filtered.filter(g => g.subEmbargoes.some(sub => sub.society === filters.society));
        if (filters.state) filtered = filtered.filter(g => getGroupState(g) === filters.state);
        filtered.sort((a, b) => {
            const key = sortConfig.key;
            let valA, valB;
            if (key === 'totalActiveAmount') { valA = calculateTotalActiveAmount(a.subEmbargoes); valB = calculateTotalActiveAmount(b.subEmbargoes); }
            else if (key === 'totalCapturedAmount') { valA = calculateTotalCapturedAmount(a.subEmbargoes); valB = calculateTotalCapturedAmount(b.subEmbargoes); }
            else { valA = a[key]; valB = b[key]; }
            if (valA < valB) return sortConfig.direction === 'ascending' ? -1 : 1;
            if (valA > valB) return sortConfig.direction === 'ascending' ? 1 : -1;
            return 0;
        });
        return filtered;
    }, [groupedEmbargoes, filters, sortConfig]);
    const requestSort = (key) => { let d = 'ascending'; if (sortConfig.key === key && sortConfig.direction === 'ascending') d = 'descending'; setSortConfig({ key, direction: d }); };
    const getSortIcon = (key) => { if (sortConfig.key !== key) return <ChevronsUpDown className="h-4 w-4 ml-1 text-gray-400" />; return sortConfig.direction === 'ascending' ? '▲' : '▼'; };
    const can = (permission) => currentRole.permissions.includes(permission);
    const casesForMassApprove = useMemo(() => groupedEmbargoes.filter(g => g.state === 'Pendiente de Transferencia'), [groupedEmbargoes]);
    const showMassApprove = can('approve') && casesForMassApprove.length > 0;
    return (
        <div className="p-8">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-gray-800">Lista de Casos de Embargo</h1>
                <div className="flex items-center space-x-2">
                    {showMassApprove && <button onClick={() => onMassApprove(casesForMassApprove)} className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 flex items-center animate-pulse"><ShieldCheck className="mr-2 h-4 w-4" /> Aprobar {casesForMassApprove.length} Caso(s)</button>}
                    <button className="bg-white text-gray-700 px-4 py-2 rounded-md border hover:bg-gray-50 flex items-center"><FileDown className="mr-2 h-4 w-4" /> Exportar .CSV</button>
                    {can('create') && <button onClick={() => setPage({ name: 'create' })} className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center"><PlusCircle className="mr-2 h-4 w-4" /> Crear Nuevo Embargo</button>}
                </div>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6 flex items-center space-x-4">
                <Filter className="h-5 w-5 text-gray-500"/>
                <input type="text" placeholder="Buscar por CUIT/DNI..." value={filters.cuit} onChange={e => setFilters({...filters, cuit: e.target.value})} className="p-2 border rounded-md w-1/4"/>
                <select value={filters.state} onChange={e => setFilters({...filters, state: e.target.value})} className="p-2 border rounded-md"><option value="">Todos los Estados</option><option>En Curso</option><option>Pendiente de Transferencia</option><option>Completo</option><option>Levantado</option></select>
                <select value={filters.society} onChange={e => setFilters({...filters, society: e.target.value})} className="p-2 border rounded-md"><option value="">Todas las Sociedades</option><option>Mercado Pago</option><option>Mercado Crédito ALyC</option><option>Mercado SOFI</option><option>Banco de México</option></select>
            </div>
            <div className="bg-white shadow-md rounded-lg overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                        <tr>
                            <th scope="col" className="px-2 py-3 w-12"></th>
                            <th scope="col" className="px-6 py-3 cursor-pointer" onClick={() => requestSort('docket')}>Caso (Expediente) {getSortIcon('docket')}</th>
                            <th scope="col" className="px-6 py-3">Estado del Caso</th>
                            <th scope="col" className="px-6 py-3 cursor-pointer text-right" onClick={() => requestSort('totalActiveAmount')}>Monto Activo {getSortIcon('totalActiveAmount')}</th>
                            <th scope="col" className="px-6 py-3 cursor-pointer text-right" onClick={() => requestSort('totalCapturedAmount')}>Monto Capturado {getSortIcon('totalCapturedAmount')}</th>
                            <th scope="col" className="px-6 py-3 text-center">Acciones del Caso</th>
                        </tr>
                    </thead>
                    <tbody>
                        {sortedAndFilteredEmbargoes.map(group => (
                            <React.Fragment key={group.groupId}>
                                <tr className="border-b hover:bg-gray-50 bg-white font-semibold text-gray-800">
                                    <td className="px-2 py-4 text-center"><button onClick={() => toggleRow(group.groupId)} className="p-1 rounded-full hover:bg-gray-200">{expandedRows.includes(group.groupId) ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}</button></td>
                                    <td className="px-6 py-4"><Folder className="inline-block mr-2 h-5 w-5 text-yellow-500"/><div>{group.docket}</div><div className="text-xs text-gray-500 font-normal">{group.userName}</div></td>
                                    <td className="px-6 py-4"><StateBadge state={getGroupState(group)} /></td>
                                    <td className="px-6 py-4 text-right text-lg">{formatCurrency(calculateTotalActiveAmount(group.subEmbargoes))}</td>
                                    <td className="px-6 py-4 text-right text-lg text-green-700">{formatCurrency(calculateTotalCapturedAmount(group.subEmbargoes))}</td>
                                    <td className="px-6 py-4 text-center">
                                        <div className="flex items-center justify-center space-x-2">
                                            <button onClick={() => setPage({ name: 'detail', id: group.groupId })} className="p-2 text-gray-500 hover:text-blue-600 hover:bg-gray-100 rounded-full" title="Ver Detalles del Caso"><Eye className="h-5 w-5" /></button>
                                            {can('act') && getGroupState(group) === 'En Curso' && calculateTotalCapturedAmount(group.subEmbargoes) > 0 && <button onClick={() => onAction('transfer_group', null, group.groupId)} className="p-2 text-green-600 hover:text-green-800 hover:bg-green-100 rounded-full" title="Iniciar Transferencia del Caso"><Gavel className="h-5 w-5" /></button>}
                                            {can('approve') && group.state === 'Pendiente de Transferencia' && <button onClick={() => onAction('approve_group', null, group.groupId)} className="p-2 text-indigo-600 hover:text-indigo-800 hover:bg-indigo-100 rounded-full animate-pulse" title="Aprobar Transferencia del Caso"><ShieldCheck className="h-5 w-5" /></button>}
                                        </div>
                                    </td>
                                </tr>
                                {expandedRows.includes(group.groupId) && (
                                    <>
                                      {group.subEmbargoes.map(sub => (
                                        <tr key={sub.id} className="bg-gray-50 hover:bg-gray-100 text-sm">
                                            <td colSpan="2" className="px-6 py-3 pl-16"><FileText className="inline-block mr-2 h-4 w-4 text-gray-400"/>{sub.society}</td>
                                            <td className="px-6 py-3"><StateBadge state={sub.state} /></td>
                                            <td className="px-6 py-3 text-right font-medium" colSpan="2">
                                                <div className="flex flex-col items-end">
                                                    <span>{formatCurrency(sub.capturedAmount)} / {formatCurrency(sub.amount)}</span>
                                                    <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1"><div className="bg-green-600 h-1.5 rounded-full" style={{width: `${(sub.capturedAmount/sub.amount)*100}%`}}></div></div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-3 text-center"><ActionsDropdown subEmbargo={sub} onAction={onAction} currentRole={currentRole} groupId={group.groupId} /></td>
                                        </tr>
                                      ))}
                                    </>
                                )}
                            </React.Fragment>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

const EmbargoDetailPage = ({ embargoGroup, onBack, onAction, currentRole }) => {
    if (!embargoGroup) return <div className="p-8">Caso de embargo no encontrado.</div>;
    const allHistory = embargoGroup.subEmbargoes.flatMap(sub => sub.history.map(h => ({...h, society: sub.society}))).sort((a,b) => new Date(b.date) - new Date(a.date));
    return (
        <div className="p-8 animate-fade-in">
            <button onClick={onBack} className="mb-6 text-blue-600 hover:text-blue-800 font-semibold flex items-center">&larr; Volver a la lista</button>
            <div className="bg-white shadow-xl rounded-lg">
                <div className="p-6 border-b flex justify-between items-start">
                    <div><h1 className="text-3xl font-bold text-gray-900">Caso: {embargoGroup.docket}</h1><p className="text-gray-600">para <span className="font-semibold">{embargoGroup.userName}</span> ({embargoGroup.userCuit})</p></div>
                    <div><p className="text-right font-bold text-2xl text-blue-700">{formatCurrency(calculateTotalActiveAmount(embargoGroup.subEmbargoes))}</p><p className="text-right text-gray-500">Monto Activo Total</p></div>
                </div>
                <div className="p-6"><h3 className="font-bold text-xl text-gray-800 mb-4">Desglose por Sociedad</h3><div className="space-y-4">{embargoGroup.subEmbargoes.map(sub => (<div key={sub.id} className="p-4 border rounded-md"><div className="flex justify-between items-center"><div className="font-bold text-lg">{sub.society}</div><StateBadge state={sub.state} /></div><div className="flex justify-between items-center mt-2"><div className="text-lg">{formatCurrency(sub.capturedAmount)} / {formatCurrency(sub.amount)}</div><ActionsDropdown subEmbargo={sub} onAction={onAction} currentRole={currentRole} groupId={embargoGroup.groupId} /></div></div>))}</div></div>
                <div className="p-6 border-t">
                    <div className="flex justify-between items-center mb-4"><h3 className="font-bold text-lg text-gray-800">Historial de Auditoría Consolidado</h3></div>
                    <div className="overflow-y-auto max-h-60 pr-2"><ul className="space-y-4">{allHistory.map((item, index) => (<li key={index} className="flex items-start"><div className="flex-shrink-0"><CheckCircle className="h-5 w-5 text-green-500 mt-1" /></div><div className="ml-3"><p className="text-sm font-semibold text-gray-700">[{item.society}] {item.action} <span className="font-normal text-gray-500">por {item.user}</span></p><p className="text-sm text-gray-600">{item.details}</p><p className="text-xs text-gray-400">{new Date(item.date).toLocaleString('es-AR')}</p></div></li>))}</ul></div>
                </div>
            </div>
        </div>
    );
};

const TransferModal = ({ isOpen, onClose, group, onConfirm }) => {
    const [cbu, setCbu] = useState('');
    const [cuit, setCuit] = useState('');
    const [banco, setBanco] = useState('');
    const [fechaPeticion, setFechaPeticion] = useState(new Date().toISOString().split('T')[0]);
    const [cbuValidated, setCbuValidated] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [transferType, setTransferType] = useState('total');
    const [partialAmount, setPartialAmount] = useState('');
    const totalCaptured = useMemo(() => (group ? calculateTotalCapturedAmount(group.subEmbargoes) : 0), [group]);
    
    useEffect(() => {
        if (isOpen) {
            setCbu(''); setCuit(''); setBanco('');
            setFechaPeticion(new Date().toISOString().split('T')[0]);
            setCbuValidated(false); setIsSubmitting(false);
            setTransferType('total'); setPartialAmount('');
        }
    }, [isOpen]);

    const handleCbuChange = (e) => { const v = e.target.value.replace(/\D/g, ''); if (v.length <= 22) { setCbu(v); setCbuValidated(false); } };
    const handleValidateCbu = () => { if (cbu.length === 22) { setCbuValidated(true); } else { alert("El CBU debe tener 22 dígitos."); } };
    const handleSubmit = (e) => {
        e.preventDefault();
        const amountToTransfer = transferType === 'total' ? totalCaptured : parseFloat(partialAmount || 0);
        if (amountToTransfer <= 0) { alert("El monto a transferir debe ser mayor a cero."); return; }
        if (amountToTransfer > totalCaptured) { alert("El monto parcial no puede exceder el total capturado."); return; }
        setIsSubmitting(true);
        setTimeout(() => { onConfirm({ groupId: group.groupId, cbu, cuit, banco, fechaPeticion, amount: amountToTransfer }); setIsSubmitting(false); onClose(); }, 1000);
    };

    if (!isOpen || !group) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-40 flex justify-center items-center">
            <div className="bg-white rounded-lg p-8 shadow-2xl w-full max-w-2xl m-4 animate-fade-in">
                <h2 className="text-2xl font-bold text-gray-800 mb-2">Iniciar Transferencia de Caso</h2>
                <p className="text-gray-600 mb-6">Caso: <span className="font-semibold">{group.docket}</span>. Total capturado disponible: <span className="font-semibold text-green-700">{formatCurrency(totalCaptured)}</span></p>
                <form onSubmit={handleSubmit}>
                    <div className="space-y-4">
                        <div><label className="block text-sm font-medium text-gray-700">CBU (22 dígitos) *</label><div className="flex items-center space-x-2 mt-1"><input type="text" value={cbu} onChange={handleCbuChange} required className={`flex-grow p-2 border rounded-md ${cbuValidated ? 'border-green-500' : ''}`} /><button type="button" onClick={handleValidateCbu} disabled={cbu.length !== 22 || cbuValidated} className="px-4 py-2 rounded-md text-white bg-gray-600 hover:bg-gray-700 disabled:bg-gray-300">{cbuValidated ? 'Validado' : 'Validar CBU'}</button></div></div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4"><div><label className="block text-sm font-medium text-gray-700">CUIT de cuenta destino *</label><input type="text" value={cuit} onChange={e => setCuit(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" /></div><div><label className="block text-sm font-medium text-gray-700">Banco destino *</label><input type="text" value={banco} onChange={e => setBanco(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" /></div></div>
                        <div><label className="block text-sm font-medium text-gray-700">Tipo de Transferencia</label><div className="flex items-center space-x-4 mt-1"><label className="flex items-center"><input type="radio" name="transferType" value="total" checked={transferType==='total'} onChange={() => setTransferType('total')} className="h-4 w-4" /> <span className="ml-2">Total Capturado ({formatCurrency(totalCaptured)})</span></label><label className="flex items-center"><input type="radio" name="transferType" value="partial" checked={transferType==='partial'} onChange={() => setTransferType('partial')} className="h-4 w-4" /> <span className="ml-2">Parcial</span></label></div></div>
                        {transferType === 'partial' && <div><label className="block text-sm font-medium text-gray-700">Monto Parcial a Transferir</label><input type="number" value={partialAmount} onChange={e => setPartialAmount(e.target.value)} max={totalCaptured} className="mt-1 w-full p-2 border rounded-md" /></div>}
                        <div><label className="block text-sm font-medium text-gray-700">Fecha de petición solicitada *</label><input type="date" value={fechaPeticion} onChange={e => setFechaPeticion(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" /></div>
                    </div>
                    <div className="flex justify-end space-x-4 mt-8"><button type="button" onClick={onClose} className="px-6 py-2 rounded-md text-gray-700 bg-gray-200 hover:bg-gray-300 font-semibold">Cancelar</button><button type="submit" disabled={isSubmitting || !cbuValidated} className="px-6 py-2 rounded-md text-white bg-blue-600 hover:bg-blue-700 font-semibold disabled:bg-blue-300 flex items-center justify-center w-40">{isSubmitting ? <Spinner /> : 'Confirmar Transferencia'}</button></div>
                </form>
            </div>
        </div>
    );
};

// --- MAIN APP COMPONENT ---
export default function App() {
  const [currentRole, setCurrentRole] = useState(ROLES.CREATOR);
  const [currentPage, setCurrentPage] = useState({ name: 'list' });
  const [groupedEmbargoes, setGroupedEmbargoes] = useState(INITIAL_GROUPED_EMBARGOES);
  const [notification, setNotification] = useState({ message: '', type: 'info' });
  const [modal, setModal] = useState({ isOpen: false });
  const [transferModalInfo, setTransferModalInfo] = useState({ isOpen: false, group: null });

  useEffect(() => {
    const interval = setInterval(() => {
        setGroupedEmbargoes(prevGroups => {
            return prevGroups.map(group => ({
                ...group,
                subEmbargoes: group.subEmbargoes.map(sub => {
                    if (sub.state === 'En Proceso' && sub.capturedAmount < sub.amount) {
                        const increment = sub.amount * 0.05; // Capture 5% each interval
                        const newCapturedAmount = Math.min(sub.capturedAmount + increment, sub.amount);
                        return {
                            ...sub,
                            capturedAmount: newCapturedAmount,
                            state: newCapturedAmount >= sub.amount ? 'Completo' : 'En Proceso',
                        };
                    }
                    return sub;
                })
            }));
        });
    }, 5000); // Simulate capturing funds every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const showNotification = (message, type = 'success') => { setNotification({ message, type }); };

  const handleCreateEmbargo = (formData) => {
    const { foundUser, subAmounts, docket, ...otherData } = formData;
    const newSubEmbargoes = [];
    for (const accountId in subAmounts) {
        const amount = parseFloat(subAmounts[accountId] || 0);
        if (amount > 0) {
            const account = foundUser.accounts.find(a => a.id === accountId);
            if (account) {
                const capturedAmount = Math.min(amount, account.balance);
                const state = capturedAmount >= amount ? 'Completo' : 'En Proceso';
                newSubEmbargoes.push({
                    id: `EMB-${Date.now()}-${account.society.slice(0,2)}`, state, society: account.society,
                    accountsInvolved: [accountId], amount, capturedAmount,
                    history: [{ action: 'Creación', user: 'creator@mercadolibre.com', date: new Date().toISOString(), details: `Embargo creado por ${formatCurrency(amount)}. Captura inicial: ${formatCurrency(capturedAmount)}` }],
                    ...otherData
                });
            }
        }
    }
    const newGroup = {
        groupId: `CASE-${foundUser.cuit.replace(/-/g, '')}-${docket}`, userCuit: foundUser.cuit.replace(/-/g, ''),
        userName: foundUser.name, docket, caseNumber: otherData.caseNumber, court: otherData.court,
        createdDate: new Date().toISOString(), subEmbargoes: newSubEmbargoes, state: 'En Curso', transfers: []
    };
    setGroupedEmbargoes([newGroup, ...groupedEmbargoes]);
    setCurrentPage({ name: 'list' });
    showNotification(`Nuevo caso de embargo creado con ${newSubEmbargoes.length} sub-embargo(s).`);
  };

  const handleAction = (action, subEmbargoId, groupId) => {
      const group = groupedEmbargoes.find(g => g.groupId === groupId);
      if (!group) return;
      if (action === 'lift' || action === 'modify') {
          const subEmbargo = group.subEmbargoes.find(s => s.id === subEmbargoId);
          if (!subEmbargo) return;
          if (action === 'lift') {
              setModal({ isOpen: true, title: 'Levantar Sub-Embargo', message: `¿Confirma que desea levantar el embargo de ${formatCurrency(subEmbargo.amount)} para ${subEmbargo.society}?`, onConfirm: () => {
                  setGroupedEmbargoes(prev => prev.map(g => g.groupId === groupId ? {...g, subEmbargoes: g.subEmbargoes.map(s => s.id === subEmbargoId ? {...s, state: 'Levantado', history: [...s.history, {action: 'Levantamiento Total', user: 'creator@mercadolibre.com', date: new Date().toISOString(), details: 'Levantamiento total del sub-embargo.'}]} : s)} : g));
                  showNotification(`Sub-embargo ${subEmbargoId} levantado.`);
                  setModal({isOpen: false});
              }, onCancel: () => setModal({isOpen: false}) });
          } else { showNotification('Funcionalidad de Modificación en desarrollo.', 'info'); }
      } else if (action === 'transfer_group') {
          setTransferModalInfo({ isOpen: true, group });
      } else if (action === 'approve_group') {
          setModal({ isOpen: true, title: 'Aprobar Transferencia de Caso', message: `¿Confirma la aprobación de la transferencia por ${formatCurrency(group.transfers.find(t=>t.status==='Pendiente Aprobación').amount)} para el caso ${group.docket}?`, onConfirm: () => {
              setGroupedEmbargoes(prev => prev.map(g => {
                  if (g.groupId === groupId) {
                      const transferToApprove = g.transfers.find(t => t.status === 'Pendiente Aprobación');
                      if (!transferToApprove) return g;
                      let remainingToDeduct = transferToApprove.amount;
                      const updatedSubEmbargoes = g.subEmbargoes.map(s => {
                          if (s.state === 'Completo' && remainingToDeduct > 0) {
                              const deduction = Math.min(s.capturedAmount, remainingToDeduct);
                              remainingToDeduct -= deduction;
                              return {...s, state: 'Transferido', capturedAmount: s.capturedAmount - deduction, history: [...s.history, {action: 'Transferencia Completada', user: 'system', date: new Date().toISOString(), details: `Transferencia de ${formatCurrency(deduction)}.`}]};
                          }
                          return s;
                      });
                      return {...g, state: 'En Curso', subEmbargoes: updatedSubEmbargoes, transfers: g.transfers.map(t => t.id === transferToApprove.id ? {...t, status: 'Completada'} : t)};
                  }
                  return g;
              }));
              showNotification(`Transferencia para el caso ${groupId} aprobada.`);
              setModal({isOpen: false});
          }, onCancel: () => setModal({isOpen: false}) });
      }
  };

  const handleConfirmTransfer = (transferData) => {
      const { groupId, ...details } = transferData;
      setGroupedEmbargoes(prev => prev.map(g => g.groupId === groupId ? { ...g, state: 'Pendiente de Transferencia', transfers: [...g.transfers, { id: `TRN-${Date.now()}`, ...details, status: 'Pendiente Aprobación' }] } : g));
      showNotification(`Transferencia para el caso ${groupId} iniciada.`);
      setTransferModalInfo({ isOpen: false, group: null });
  };
  
  const handleMassApprove = (casesToApprove) => {
    setModal({
        isOpen: true, title: 'Aprobación Masiva', message: `¿Confirma que desea aprobar ${casesToApprove.length} casos?`,
        onConfirm: () => {
            let updatedGroups = [...groupedEmbargoes];
            casesToApprove.forEach(caseToApprove => {
                updatedGroups = updatedGroups.map(g => {
                    if (g.groupId === caseToApprove.groupId) {
                        return {...g, state: 'Completo', subEmbargoes: g.subEmbargoes.map(s => s.state === 'En Proceso' ? {...s, state: 'Transferido', history: [...s.history, {action: 'Transferencia Completada', user: 'system', date: new Date().toISOString(), details: 'Transferencia completada por aprobación masiva.'}]} : s)};
                    }
                    return g;
                });
            });
            setGroupedEmbargoes(updatedGroups);
            showNotification(`${casesToApprove.length} casos aprobados con éxito.`);
            setModal({isOpen: false});
        },
        onCancel: () => setModal({ isOpen: false })
    });
  };

  const renderPage = () => {
    switch (currentPage.name) {
      case 'detail':
        const embargoGroup = groupedEmbargoes.find(e => e.groupId === currentPage.id);
        return <EmbargoDetailPage embargoGroup={embargoGroup} onBack={() => setCurrentPage({ name: 'list' })} onAction={handleAction} currentRole={currentRole} />;
      case 'create':
        return <CreateEmbargoPage onEmbargoCreate={handleCreateEmbargo} setCurrentPage={setCurrentPage} />;
      case 'bulk':
        return (<div className="p-8">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-gray-800">Carga Masiva de Embargos</h1>
                <button onClick={() => setCurrentPage({name: 'list'})} className="text-blue-600 hover:text-blue-800 font-semibold flex items-center">
                    &larr; Volver a la lista
                </button>
            </div>
            <p className="mt-4">Esta funcionalidad para subir archivos .CSV está en desarrollo.</p>
        </div>);
      case 'lookup':
        return (<div className="p-8">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-gray-800">Consulta de Cuentas y Saldos</h1>
                <button onClick={() => setCurrentPage({name: 'list'})} className="text-blue-600 hover:text-blue-800 font-semibold flex items-center">
                    &larr; Volver a la lista
                </button>
            </div>
            <AccountLookupComponent />
        </div>);
      case 'list':
      default:
        return <EmbargoListPage groupedEmbargoes={groupedEmbargoes} onAction={handleAction} currentRole={currentRole} setPage={setCurrentPage} onMassApprove={handleMassApprove} />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100 font-sans">
      <style>{`.animate-fade-in { animation: fadeIn 0.5s ease-in-out; } .animate-fade-in-down { animation: fadeInDown 0.5s ease-in-out; } @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } } @keyframes fadeInDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } } .animate-pulse-once { animation: pulse-bg 2s ease-in-out; } @keyframes pulse-bg { 0% { background-color: #f0fdf4; } 50% { background-color: #dcfce7; } 100% { background-color: #f0fdf4; } }`}</style>
      <ToastNotification message={notification.message} type={notification.type} onDismiss={() => setNotification({ message: '', type: 'info' })} />
      <ConfirmationModal {...modal} />
      <TransferModal isOpen={transferModalInfo.isOpen} onClose={() => setTransferModalInfo({ isOpen: false, group: null })} group={transferModalInfo.group} onConfirm={handleConfirmTransfer} />
      <Sidebar setCurrentPage={setCurrentPage} />
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white shadow-sm h-16 flex items-center justify-end px-8 border-b">
            <div className="flex items-center"><span className="text-gray-600 mr-3">Rol Actual:</span><select value={currentRole.name} onChange={(e) => setCurrentRole(Object.values(ROLES).find(r => r.name === e.target.value))} className="font-semibold p-2 border rounded-md bg-gray-50">{Object.values(ROLES).map(r => <option key={r.name}>{r.name}</option>)}</select></div>
        </header>
        <div className="flex-1 overflow-y-auto">{renderPage()}</div>
      </main>
    </div>
  );
}

